package universitylibrary;

public class Model {
    Model()
    {
        
    }
    private String id,name,dept,password;

    public void setDept(String dept) {
        this.dept = dept;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDept() {
        return dept;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }
    
}

package universitylibrary;

public class BookModel {
    BookModel()
    {
        
    }
    private String CallNo,BookName,Writer,Quantity;

    public void setBookName(String BookName) {
        this.BookName = BookName;
    }

    public void setCallNo(String CallNo) {
        this.CallNo = CallNo;
    }

    public void setQuantity(String Quantity) {
        this.Quantity = Quantity;
    }

    public void setWriter(String Writer) {
        this.Writer = Writer;
    }

    public String getBookName() {
        return BookName;
    }

    public String getCallNo() {
        return CallNo;
    }

    public String getQuantity() {
        return Quantity;
    }

    public String getWriter() {
        return Writer;
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitylibrary;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class ClearDB {
    private Controller control=new Controller();
    ClearDB()
    {
        init();
    }
    private void init()
    {
        JFrame frame=new JFrame();
        JLabel head;
        
        Font font;
        Container c;
        font=new Font("Arial",Font.BOLD,18);
        frame.setVisible(true);
        frame.setTitle("Library Management System");
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	c =frame.getContentPane();
	c.setLayout(null);
        c.setBackground(Color.ORANGE);
        frame.setBounds(0,0,1000,1000);
        
        head=new JLabel("Clear");
        head.setBounds(100,10,200,30);
        head.setFont(font);
        
        c.add(head);
        
        JLabel lbltbl=new JLabel("Enter Database");
        JTextField txttbl=new JTextField();
        
        lbltbl.setBounds(10,100,150,30);
        lbltbl.setFont(font);
        txttbl.setBounds(200,100,200,30);
        txttbl.setFont(font);
        
        JButton btntake=new JButton("Clear"),btnback=new JButton("Back");
        btntake.setBounds(100,160,100,30);
        btntake.setFont(font);
        btnback.setBounds(100,200,100,30);
        btnback.setFont(font);
        
        c.add(lbltbl);c.add(txttbl);
        c.add(btntake);c.add(btnback);
        
        btntake.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                if(control.EmptyTable(txttbl.getText()))JOptionPane.showMessageDialog(null,"Database cleared");
                else JOptionPane.showMessageDialog(null,"Something wrong");
                AdminSection o=new AdminSection();
            }
        });
        
        btnback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
               AdminSection s=new AdminSection(); 
            }
        });
    }
    public static void main(String[] args) {
        ClearDB ob=new ClearDB();
    }
}

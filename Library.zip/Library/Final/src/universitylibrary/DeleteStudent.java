package universitylibrary;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class DeleteStudent {
    private Controller control=new Controller();
    private Model m=new Model();
    DeleteStudent()
    {
        init();
    }
    private void init()
    {
        JFrame frame=new JFrame();
        frame.setVisible(true);
        Container c=frame.getContentPane();
        Font font=new Font("Arial",Font.BOLD,18);
        frame.setVisible(true);
        frame.setTitle("Library Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
        c.setLayout(null);
        c.setBackground(Color.ORANGE);
        frame.setBounds(0,0,1000,1000);
        
        JLabel head=new JLabel("Remove Students");
        head.setBounds(200,10,150,30);
        head.setFont(font);
        c.add(head);
        
        JLabel lblid=new JLabel("Enter ID"),lblpass=new JLabel("Enter password");
        JButton btndlt=new JButton("Delete"),btnback=new JButton("Back");
        JTextField txtid=new JTextField();
        
        JPasswordField txtpass=new JPasswordField();
        
        lblid.setBounds(10,100,150,30);
        lblid.setFont(font);
        txtid.setBounds(200,100,200,30);
        txtid.setFont(font);
        lblpass.setBounds(10,140,150,30);
        lblpass.setFont(font);
        txtpass.setBounds(200,140,200,30);
        txtpass.setFont(font);
        
        btndlt.setBounds(100,200,150,30);
        btndlt.setFont(font);
        btnback.setBounds(100,250,150,30);
        btnback.setFont(font);
        
        c.add(lblid);
        c.add(txtid);
        c.add(lblpass);
        c.add(txtpass);
        c.add(btndlt);
        c.add(btnback);
        
        btndlt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                String t="student_form";
                String Id=txtid.getText();
                String Pass=txtpass.getText();
                if(control.CheckStudentValidity(t, Id, Pass))
                {
                    if(control.DeleteAddStudentTable(t, Id))JOptionPane.showMessageDialog(null,"Student Deleted");
                    else JOptionPane.showMessageDialog(null,"Something wrong.");
                }
                else JOptionPane.showMessageDialog(null,"You are not registered yet.");
            }
        });
        
        btnback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                AdminSection section=new AdminSection();
            }
        });
        
    }
    public static void main(String[] args) {
        DeleteStudent ob=new DeleteStudent();
    }
    
}

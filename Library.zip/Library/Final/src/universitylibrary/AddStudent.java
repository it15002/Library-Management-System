package universitylibrary;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class AddStudent {
    private Controller control=new Controller();
    private Model m=new Model();
    AddStudent()
    {
        init();
    }
    private void init()
    {
        JFrame frame=new JFrame();
        frame.setVisible(true);
        Container c=frame.getContentPane();
        Font font=new Font("Arial",Font.BOLD,18);
        frame.setVisible(true);
        frame.setTitle("Library Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
        c.setLayout(null);
        c.setBackground(Color.ORANGE);
        frame.setBounds(0,0,1000,1000);
        
        JLabel head=new JLabel("Add Students");
        head.setBounds(200,10,150,30);
        head.setFont(font);
        c.add(head);
        
        JLabel lblid=new JLabel("ID: "),lblname=new JLabel("Name: "),lbldept=new JLabel("Dept: "),lblpass=new JLabel("Password");
        JTextField txtid=new JTextField(),txtname=new JTextField(),txtdept=new JTextField();
        JPasswordField txtpass=new JPasswordField();
        JButton btnaddstdnt=new JButton("Add Students"),btnback=new JButton("Back");
        
        lblid.setBounds(10,100,150,30);
        lblid.setFont(font);
        txtid.setBounds(200,100,200,30);
        txtid.setFont(font);
        lblname.setBounds(10,140,150,30);
        lblname.setFont(font);
        txtname.setBounds(200,140,200,30);
        txtname.setFont(font);
        lbldept.setBounds(10,180,150,30);
        lbldept.setFont(font);
        txtdept.setBounds(200,180,200,30);
        txtdept.setFont(font);
        lblpass.setBounds(10,220,150,30);
        lblpass.setFont(font);
        txtpass.setBounds(200,220,200,30);
        txtpass.setFont(font);
        
        btnaddstdnt.setBounds(100,270,150,30);
        btnaddstdnt.setFont(font);
        btnback.setBounds(100,320,150,30);
        btnback.setFont(font);
        
        c.add(lblid);
        c.add(txtid);
        c.add(lblname);
        c.add(txtname);
        c.add(lbldept);
        c.add(txtdept);
        c.add(lblpass);
        c.add(txtpass);
        c.add(btnaddstdnt);
        c.add(btnback);
        
        
        btnaddstdnt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                m.setId(txtid.getText());
                m.setName(txtname.getText());
                m.setDept(txtdept.getText());
                m.setPassword(txtpass.getText());
                String t="student_form";
                if(control.CheckAddStudentTable(t, txtid.getText()))
                {
                    if(control.InsertAddStudentTable(t, m))JOptionPane.showMessageDialog(null,"Successfully Registered!");
                    else JOptionPane.showMessageDialog(null,"Something wrong.");
                }
                else JOptionPane.showMessageDialog(null,"Already Registered");
            }
        });
        
        btnback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                AdminSection section=new AdminSection();
            }
        });
    }
    public static void main(String[] args) {
        AddStudent ob=new AddStudent();
    }
    
}

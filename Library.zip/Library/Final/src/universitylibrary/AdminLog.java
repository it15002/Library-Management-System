/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitylibrary;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class AdminLog extends JFrame
{
    AdminLog()
    {
        Tables ob=new Tables();
        init();
    }
    private void init()
    {
        Container c;
        JButton btnadmin,btnlibrary;
        Font font;
        font=new Font("Arial",Font.BOLD,18);
        JFrame frame=new JFrame();
        frame.setVisible(true);
        frame.setTitle("Library Management System");
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	c =frame.getContentPane();
	c.setLayout(null);
        c.setBackground(Color.ORANGE);
        frame.setBounds(0,0,1000,1000);
        
        btnadmin=new JButton("Admin Login");
        btnadmin.setBounds(100,10,200,30);
        btnadmin.setFont(font);
        
        btnlibrary=new JButton("Student Login");
        btnlibrary.setBounds(100,60,200,30);
        btnlibrary.setFont(font);
        
        btnadmin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                LoginForm form=new LoginForm();
            }
        });
        
        btnlibrary.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                StudentLog o=new StudentLog();
            }
        });
        JButton exitbtn=new JButton("Exit");
        exitbtn.setBounds(100,100,200,30);
        exitbtn.setFont(font);
        c.add(exitbtn);
        
        exitbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                
            }
        });
        
        c.add(btnadmin);
        c.add(btnlibrary);
        
    }
    public static void main(String[] args) {
        AdminLog frame=new AdminLog();
        
    }
}

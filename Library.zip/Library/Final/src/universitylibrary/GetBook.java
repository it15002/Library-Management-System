package universitylibrary;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class GetBook {
    private ResultSet rs=null;
    private Controller control=new Controller();
    GetBook()
    {
        init();
    }
    private void init()
    {
        JFrame frame=new JFrame();
        JLabel head;
        
        Font font;
        Container c;
        font=new Font("Arial",Font.BOLD,18);
        frame.setVisible(true);
        frame.setTitle("Library Management System");
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	c =frame.getContentPane();
	c.setLayout(null);
        c.setBackground(Color.ORANGE);
        frame.setBounds(0,0,1000,1000);
        
        head=new JLabel("Get Book");
        head.setBounds(100,10,200,30);
        head.setFont(font);
        
        c.add(head);
        
        JLabel lblid=new JLabel("Enter ID"),lblcall=new JLabel("Enter CallNo"),lbltakendate=new JLabel("Enter Date");
        JTextField txtid=new JTextField(),txtcall=new JTextField(),txttakendate=new JTextField();
        
        lblid.setBounds(10,100,150,30);
        lblid.setFont(font);
        txtid.setBounds(200,100,200,30);
        txtid.setFont(font);
        lblcall.setBounds(10,140,150,30);
        lblcall.setFont(font);
        txtcall.setBounds(200,140,200,30);
        txtcall.setFont(font);
        lbltakendate.setBounds(10,180,150,30);
        lbltakendate.setFont(font);
        txttakendate.setBounds(200,180,200,30);
        txttakendate.setFont(font);
        txttakendate.setToolTipText("Format: YY-MM-DD");
        JButton btntake=new JButton("Taken"),btnback=new JButton("Back");
        btntake.setBounds(100,240,100,30);
        btntake.setFont(font);
        btnback.setBounds(100,280,100,30);
        btnback.setFont(font);
        
        c.add(lblid);c.add(txtid);c.add(lblcall);c.add(txtcall);
        c.add(lbltakendate);c.add(txttakendate);c.add(btntake);c.add(btnback);
        
        btntake.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                String sq="select *from student_form where ID='"+txtid.getText()+"';";
                String x="";
                try {
                    rs=control.DBState().executeQuery(sq);
                    while(rs.next())
                    {
                        x=rs.getString("ID");
                    }
                    
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Something wrong");
                    ex.printStackTrace();
                }
                if(x.length()==0)
                {
                    JOptionPane.showMessageDialog(null,"Please Register first");
                }
                else
                {
                x="";
                boolean check=false;
                String sql="select *from books where CallNo='"+txtcall.getText()+"';";
                try {
                    rs=control.DBState().executeQuery(sql);
                    while(rs.next())x=rs.getString("Quantity");
                    
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Something wrong");
                    ex.printStackTrace();
                }
                if(!x.equals("")||!x.equals("0"))
                {
                    int c=0;
                    String fine="";
                    try {
                        sql="select *from bookservice where ID='"+txtid.getText()+"';";
                        rs=control.DBState().executeQuery(sql);
                        
                        while(rs.next())
                        {
                            c++;
                            fine=rs.getString("Fine");
                        }
                        
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(null, "Something wrong");
                        ex.printStackTrace();
                    }
                    if(fine.equals(""))fine="0";
                    JOptionPane.showMessageDialog(null,"Please pay "+fine+" Tk before taking the book");
                    check=true;
                    if(c==0||check)
                    {
                        x="";
                        if(c==0)sql="insert into bookservice values('"+txtid.getText()+"','"+txtcall.getText()+"','"+txttakendate.getText()+"','"+x+"','"+x+"');";
                        else sql="update bookservice set CallNo='"+txtcall.getText()+"',Taken_Date='"+txttakendate.getText()+"',Fine='"+x+"',Return_Date='"+x+"' where ID='"+txtid.getText()+"';";
                        try {
                            control.DBState().executeUpdate(sql);
                            control.CloseAll();
                            JOptionPane.showMessageDialog(null, "Succesfully taken");
                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(null, "Something wrong");
                            ex.printStackTrace();
                        }
                        sql="select Quantity from books where CallNo='"+txtcall.getText()+"';";
                        try{
                            rs=control.DBState().executeQuery(sql);
                            
                            int book=0;
                            while(rs.next())book=Integer.valueOf(rs.getString("Quantity"));
                            control.CloseAll();
                            book--;
                            if(book>0)x=String.valueOf(book);
                            else x="";
                        }catch (Exception ex) {
                            ex.printStackTrace();
                        }
                        
                        sql="update books set Quantity='"+x+"' where CallNo='"+txtcall.getText()+"';";
                        try{
                            control.DBState().executeUpdate(sql);
                            control.CloseAll();
                        }catch (Exception ex) {
                            ex.printStackTrace();
                        }
                        
                    }
                    
                    else JOptionPane.showMessageDialog(null,"First return previous book.");    
                }
                else JOptionPane.showMessageDialog(null,"Book unavailable");
                
            }
                }
        });
        
        btnback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
               StudentSection s=new StudentSection(); 
            }
        });
    }
    public static void main(String[] args) {
        GetBook ob=new GetBook();
        
    }
}

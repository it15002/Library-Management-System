package universitylibrary;

public class BookServeModel {
    BookServeModel()
    {
        
    }
    private String Id,Callno,taken_date,return_date,fine;

    public void setCallno(String Callno) {
        this.Callno = Callno;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public void setFine(String fine) {
        this.fine = fine;
    }

    public void setReturn_date(String return_date) {
        this.return_date = return_date;
    }

    public void setTaken_date(String taken_date) {
        this.taken_date = taken_date;
    }

    public String getCallno() {
        return Callno;
    }

    public String getId() {
        return Id;
    }

    public String getFine() {
        return fine;
    }

    public String getReturn_date() {
        return return_date;
    }

    public String getTaken_date() {
        return taken_date;
    }
    
    
}

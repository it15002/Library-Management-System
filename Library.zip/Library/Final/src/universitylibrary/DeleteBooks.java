package universitylibrary;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class DeleteBooks {
    private Controller control=new Controller();
    DeleteBooks()
    {
        init();
    }
    private void init()
    {
        JFrame frame=new JFrame();
        Container c=frame.getContentPane();
        Font font=new Font("Arial",Font.BOLD,18);
        frame.setTitle("Library Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        c.setLayout(null);
        c.setBackground(Color.ORANGE);
        frame.setBounds(0,0,1000,1000);
        
        JLabel lblcall,head;
        JButton btnback,dltbtn;
        JTextField txtcall;
        
        head=new JLabel("Remove Book");
        head.setBounds(100,10,200,30);
        head.setFont(font);
        
        c.add(head);
        
        lblcall=new JLabel("Enter CallNo");
        lblcall.setBounds(10,100,150,30);
        lblcall.setFont(font);
        
        c.add(lblcall);
        
        txtcall=new JTextField();
        txtcall.setBounds(200,100,200,30);
        txtcall.setFont(font);
        
        c.add(txtcall);
        
        dltbtn=new JButton("Remove");
        dltbtn.setFont(font);
        dltbtn.setBounds(100,150,150,30);
        
        c.add(dltbtn);
        
        btnback=new JButton("Back");
        btnback.setFont(font);
        btnback.setBounds(100,200,150,30);
        
        c.add(btnback);
        
        dltbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                String call=txtcall.getText();
                String table="books";
                String x=control.CountBook(table, call);
                if(!x.equals("0"))
                {
                    if(control.RemoveBook(table, call))JOptionPane.showMessageDialog(null,"Books removed");
                    else JOptionPane.showMessageDialog(null,"Something wrong");
                }
                else JOptionPane.showMessageDialog(null,"Book not exist.");
            }
        });
        
        btnback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
              frame.dispose();
              AdminSection ob=new AdminSection();
            }
        });
    }
    public static void main(String[] args) {
        DeleteBooks ob=new DeleteBooks();
    }
    
}

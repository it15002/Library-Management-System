/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitylibrary;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


public class AdminSection {
    //add student,delete student,view student,add book,delete book,view book,view stdnt
    AdminSection()
    {
        init();
    }
    private void init()
    {
        JFrame frame=new JFrame();
        frame.setVisible(true);
        Container c=frame.getContentPane();
        Font font=new Font("Arial",Font.BOLD,18);
        frame.setVisible(true);
        frame.setTitle("Library Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
        c.setLayout(null);
        c.setBackground(Color.ORANGE);
        frame.setBounds(0,0,1000,1000);
        
        JButton btnaddstdnt,btndltstdnt,btnaddbook,btndltbook,btnviewbook,btnback,btnviewstdnt;
        
        JLabel head=new JLabel("Admin Section");
        head.setBounds(100,10,200,30);
        head.setFont(font);
        
        c.add(head);
        
        btnaddstdnt=new JButton("Add Student");
        btndltstdnt=new JButton("Delete Student");
        btnaddbook=new JButton("Add Book");
        btndltbook=new JButton("Delete Book");
        btnback=new JButton("Back");
        btnviewbook=new JButton("View Book");
        
        btnaddstdnt.setBounds(100,100,200,30);
        btnaddstdnt.setFont(font);
        c.add(btnaddstdnt);
        
        btnaddstdnt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                AddStudent add=new AddStudent();
            }
        });
        
        btndltstdnt.setBounds(100,140,200,30);
        btndltstdnt.setFont(font);
        c.add(btndltstdnt);
        
        btndltstdnt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                DeleteStudent ob=new DeleteStudent();
            }
        });
        
        btnaddbook.setBounds(100,180,200,30);
        btnaddbook.setFont(font);
        c.add(btnaddbook);
        
        btnaddbook.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                AddBooks ob=new AddBooks();
            }
        });
        
        btndltbook.setBounds(100,220,200,30);
        btndltbook.setFont(font);
        c.add(btndltbook);
        
        btndltbook.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                DeleteBooks ob=new DeleteBooks();
            }
        });
        
        btnviewstdnt=new JButton("View Student");
        btnviewstdnt.setBounds(100,260,200,30);
        btnviewstdnt.setFont(font);
        c.add(btnviewstdnt);
        
        btnviewstdnt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                ViewStudent ob=new ViewStudent();
            }
        });
        
        btnviewbook.setBounds(100,300,200,30);
        btnviewbook.setFont(font);
        c.add(btnviewbook);
        
       
        JButton btnremovealldata=new JButton("Clear");
        btnremovealldata.setBounds(100,420,200,30);
        btnremovealldata.setFont(font);
        
        c.add(btnremovealldata);
        
        btnremovealldata.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                ClearDB ob=new ClearDB();
            }
        });
        
        JButton btnfinerecord=new JButton("Fine Details");
        btnfinerecord.setFont(font);
        btnfinerecord.setBounds(100,380,200,30);
        
        c.add(btnfinerecord);
        
        btnfinerecord.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                FineRecord ob=new FineRecord();
            }
        });
        
        btnback.setBounds(100,460,200,30);
        btnback.setFont(font);
        c.add(btnback);
        
        btnviewbook.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                ViewBooks ob=new ViewBooks();
            }
        });
        btnback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                AdminLog log=new AdminLog();
            }
        });
        
    }
    public static void main(String[] args) {
        AdminSection ob=new AdminSection();
    }
    
}

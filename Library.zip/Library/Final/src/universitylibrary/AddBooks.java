package universitylibrary;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class AddBooks {
    private Controller control=new Controller();
    private BookModel m=new BookModel();
    AddBooks()
    {
        init();
    }
    private void init()
    {
        JFrame frame=new JFrame();
        frame.setVisible(true);
        Container c=frame.getContentPane();
        Font font=new Font("Arial",Font.BOLD,18);
        frame.setVisible(true);
        frame.setTitle("Library Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
        c.setLayout(null);
        c.setBackground(Color.ORANGE);
        frame.setBounds(0,0,1000,1000);
        
        JLabel head=new JLabel("Add Books");
        head.setBounds(200,10,150,30);
        head.setFont(font);
        c.add(head);
        
        JLabel lblcall=new JLabel("CallNo: "),lblbkname=new JLabel("BookName: "),lblwriter=new JLabel("Writer: "),lblquantity=new JLabel("Quantity");
        JTextField txtcall=new JTextField(),txtbkname=new JTextField(),txtwriter=new JTextField(),txtquantity=new JTextField();
        
        JButton btnaddbook=new JButton("Add Book"),btnback=new JButton("Back");
        
        lblcall.setBounds(10,100,150,30);
        lblcall.setFont(font);
        txtcall.setBounds(200,100,200,30);
        txtcall.setFont(font);
        lblbkname.setBounds(10,140,150,30);
        lblbkname.setFont(font);
        txtbkname.setBounds(200,140,200,30);
        txtbkname.setFont(font);
        lblwriter.setBounds(10,180,150,30);
        lblwriter.setFont(font);
        txtwriter.setBounds(200,180,200,30);
        txtwriter.setFont(font);
        lblquantity.setBounds(10,220,150,30);
        lblquantity.setFont(font);
        txtquantity.setBounds(200,220,200,30);
        txtquantity.setFont(font);
        
        btnaddbook.setBounds(100,270,150,30);
        btnaddbook.setFont(font);
        btnback.setBounds(100,320,150,30);
        btnback.setFont(font);
        c.add(lblcall);
        c.add(txtcall);
        c.add(lblbkname);
        c.add(txtbkname);
        c.add(lblwriter);
        c.add(txtwriter);
        c.add(lblquantity);
        c.add(txtquantity);
        c.add(btnaddbook);
        c.add(btnback);
        
        
        btnaddbook.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                String t="books";
                String x=txtcall.getText();
                m.setCallNo(x);
                m.setBookName(txtbkname.getText());
                m.setWriter(txtwriter.getText());
                x=control.CountBook(t, x);
                boolean check=true;
                if(x.equals("0"))
                {
                    m.setQuantity(txtquantity.getText());
                    if(control.InsertBook(t, m, check))JOptionPane.showMessageDialog(null,"Book added");
                    else JOptionPane.showMessageDialog(null,"Something wrong");
                            
                }
                else
                {
                    check=false;
                    x=String.valueOf(Integer.valueOf(x)+Integer.valueOf(txtquantity.getText()));
                    m.setQuantity(x);
                    if(control.InsertBook(t, m, check))JOptionPane.showMessageDialog(null,"Book added");
                    else JOptionPane.showMessageDialog(null,"Something wrong");
                }
                
            }
        });
        
        btnback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                AdminSection section=new AdminSection();
            }
        });
    }
    public static void main(String[] args) {
        AddBooks ob=new AddBooks();
    }
}

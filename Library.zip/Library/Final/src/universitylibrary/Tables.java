/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitylibrary;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Tables {
    private Controller control=new Controller();
    Tables()
    {
        init();
    }
    private void init()
    {
        String student_form="create table if not exists student_form(ID varchar(255) NOT NULL,Name varchar(255),Dept varchar(255),Password varchar(255),primary key(ID));";
        String books="create table if not exists books(CallNo varchar(255) NOT NULL,BookName varchar(255),Writer varchar(255),Quantity varchar(255),primary key(CallNo));";
        String bookservice="create table if not exists bookservice(ID varchar(255) NOT NULL,CallNo varchar(255),Taken_Date varchar(255),Return_Date varchar(255),Fine varchar(255),primary key(ID));";
        
        try{
            control.DBState().executeUpdate(student_form);
            control.CloseAll();
            //System.out.println("Created");
        }catch (Exception ex) {
            //System.out.println("Not Created");
        }
        try{
            control.DBState().executeUpdate(books);
            control.CloseAll();
            //System.out.println("Created");
        }catch (Exception ex) {
            //System.out.println("Not Created");
        }
        try{
            control.DBState().executeUpdate(bookservice);
            control.CloseAll();
            //System.out.println("Created");
        }catch (Exception ex) {
            //System.out.println("Not Created");
        }
    }
    public static void main(String[] args) {
        Tables ob=new Tables();
        
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitylibrary;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class StudentSection {
    private ResultSet rs=null;
    private Controller control=new Controller();
    StudentSection()
    {
        init();
    }
    private void init()
    {
        JFrame frame=new JFrame();
        frame.setVisible(true);
        Container c=frame.getContentPane();
        Font font=new Font("Arial",Font.BOLD,18);
        frame.setVisible(true);
        frame.setTitle("Library Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
        c.setLayout(null);
        c.setBackground(Color.ORANGE);
        frame.setBounds(0,0,1000,1000);
        
        
        
        JLabel head=new JLabel("Student Section");
        head.setBounds(100,10,200,30);
        head.setFont(font);
        
        c.add(head);
        
        JButton btnrcv=new JButton("Get Book");
        JButton btnrtrn=new JButton("Return Book");
        JButton btnback=new JButton("Back");
        JButton btnviewbook=new JButton("View Book");
        
        btnrcv.setBounds(100,100,200,30);
        btnrcv.setFont(font);
        c.add(btnrcv);
        
        btnrcv.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                GetBook ob=new GetBook();
            }
        });
        
        btnrtrn.setBounds(100,140,200,30);
        btnrtrn.setFont(font);
        c.add(btnrtrn);
        
        btnrtrn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                ReturnBook ob=new ReturnBook();
            }
        });
        
        
        
        
        btnviewbook.setBounds(100,180,200,30);
        btnviewbook.setFont(font);
        c.add(btnviewbook);
        
        
        btnback.setBounds(100,220,200,30);
        btnback.setFont(font);
        c.add(btnback);
        
        btnviewbook.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                ViewBooks ob=new ViewBooks();
            }
        });
        btnback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                AdminLog log=new AdminLog();
            }
        });
        
    }
    public static void main(String[] args) {
        StudentSection ob=new StudentSection();
    }
    
}

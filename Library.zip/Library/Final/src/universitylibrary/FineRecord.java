
package universitylibrary;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class FineRecord {
    private Controller control=new Controller();
    private BookServeModel model=new BookServeModel();
    FineRecord()
    {
        init();
    }
    private void init()
    {
        JFrame frame=new JFrame();
        Container c=frame.getContentPane();
        Font font=new Font("Arial",Font.BOLD,18);
        frame.setTitle("Library Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
        c.setLayout(null);
        c.setBackground(Color.ORANGE);
        frame.setBounds(0,0,1000,1000);
        
        JTable table=new JTable();
        DefaultTableModel tablemodel=new DefaultTableModel();
        String[] column={"ID","CallNo","Taken_Date","Return_Date","Fine"};
        String[] row=new String[5];
        tablemodel.setColumnIdentifiers(column);
        table.setEnabled(false);
        table.setModel(tablemodel);
        table.setFont(font);
        table.setSelectionBackground(Color.GREEN);
        table.setBackground(Color.YELLOW);
        table.setRowHeight(30);
        
        List<BookServeModel>m=new ArrayList<BookServeModel>();
        String tablename="bookservice";
        m=control.ViewFineRecord(tablename);
        int sz=m.size();
        if(sz<1)
        {
            
            frame.dispose();
            JOptionPane.showMessageDialog(null,"No record found");
            AdminSection section=new AdminSection();
            
        }
        else
        {
            tablemodel.getDataVector().removeAllElements();
            tablemodel.fireTableDataChanged();
            for(int i=0;i<sz;i++){
            model=m.get(i);
            row[0]=model.getId();
            row[1]=model.getCallno();
            row[2]=model.getTaken_date();
            row[3]=model.getReturn_date();
            row[4]=model.getFine();
            
            tablemodel.addRow(row);}
            frame.setVisible(true);
        }
        JScrollPane scroll=new JScrollPane(table);
        scroll.setFont(font);
        scroll.setBounds(0,0,600,300);
        
        JButton btnback=new JButton("Back");
        btnback.setBounds(300,310,100,30);
        btnback.setFont(font);
        
        btnback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                AdminSection section=new AdminSection();
            }
        });
        
        
        c.add(scroll);
        c.add(btnback);
        
    }
    public static void main(String[] args) {
           FineRecord ob=new FineRecord();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universitylibrary;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Controller {
    //private final String driver="com.mysql.jdbc.Driver";
    //private final String user="root";
    //private final String pass="";
    private String URL="jdbc:sqlite:porag.sql";
    private ResultSet rs=null;
    private Connection con=null;
    private Statement st=null;
    
    public Connection DB() throws SQLException
    {
        
        
        con=null;
        
        try{
            Class.forName("org.sqlite.JDBC");
            con= DriverManager.getConnection(URL);
            
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        return con;
    }
    
    public Statement DBState() throws SQLException
    {
        st=null;
        try{
            st=(Statement) DB().createStatement();
            
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        return st;
    }
    
    public boolean CheckAddStudentTable(String table,String id)
    {
        String x="";
        
        try{
            String sql="select ID from "+table+" where ID='"+id+"';";
        rs=DBState().executeQuery(sql);
        
        while(rs.next())x=rs.getString("ID");
        CloseAll();
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        if(x.length()==0)return true;
        return false;
    }
    
    public boolean CheckStudentValidity(String table,String id,String pass)
    {
        String x="";
        
        try{
            String sql="select ID from "+table+" where ID='"+id+"' and Password='"+pass+"';";
        rs=DBState().executeQuery(sql);
        
        while(rs.next())x=rs.getString("ID");
        CloseAll();
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        if(x.length()>0)return true;
        return false;
    }
    
    public boolean InsertAddStudentTable(String table,Model m)
    {
        try{
            String sql="insert into "+table+" values('"+m.getId()+"','"+m.getName()+"','"+m.getDept()+"','"+m.getPassword()+"');";
            DBState().executeUpdate(sql);
            CloseAll();
            return true;
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }
    
    public boolean DeleteAddStudentTable(String table,String id)
    {
        try{
            String sql="delete from "+table+" where ID='"+id+"';";
            DBState().executeUpdate(sql);
            CloseAll();
            return true;
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }
    
    public boolean RemoveBook(String table,String call)
    {
        
        try{
        String sql="delete from "+table+" where CallNo='"+call+"';";
        DBState().executeUpdate(sql);
        CloseAll();
        return true;
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        return true;
    }
    
    public boolean InsertBook(String table,BookModel m,boolean check)
    {
        String sql="";
        try{
            if(check)sql="insert into "+table+" values('"+m.getCallNo()+"','"+m.getBookName()+"','"+m.getWriter()+"','"+m.getQuantity()+"');";
            else sql="update "+table+" set Quantity='"+m.getQuantity()+"' where CallNo='"+m.getCallNo()+"';";
            DBState().executeUpdate(sql);
            CloseAll();
            return true;
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }
    public String CountBook(String table,String callno)
    {
        String ans="";
        try{
            String sql="select Quantity from "+table+" where CallNo='"+callno+"';";
            rs=DBState().executeQuery(sql);
            while(rs.next())ans=rs.getString("Quantity");
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        if(ans.length()==0)ans="0";
        return ans;
    }
    
    
    public boolean EmptyTable(String table)
    {
        try{
            String sql="delete from "+table+";";
            DBState().executeUpdate(sql);
            CloseAll();
            return true;
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }
    
    public List<Model> ViewAddStudentTable(String table)
    {
        List<Model>L=new ArrayList<Model>();
        try{
            String sql="select *from "+table+";";
            rs=DBState().executeQuery(sql);
            while(rs.next())
            {
                Model m=new Model();
                m.setId(rs.getString("ID"));
                m.setName(rs.getString("Name"));
                m.setPassword(rs.getString("Password"));
                m.setDept(rs.getString("Dept"));
                L.add(m);
                
            }
            CloseAll();
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        return L;
    }
    
    public List<BookModel> ViewBook(String table)
    {
        List<BookModel>L=new ArrayList<BookModel>();
        try{
            String sql="select *from "+table+";";
            rs=DBState().executeQuery(sql);
            while(rs.next())
            {
                BookModel m=new BookModel();
                m.setCallNo(rs.getString("CallNo"));
                m.setBookName(rs.getString("BookName"));
                m.setWriter(rs.getString("Writer"));
                m.setQuantity(rs.getString("Quantity"));
                L.add(m);
                
            }
            CloseAll();
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        return L;
    }
    
    
    public List<BookServeModel> ViewFineRecord(String table)
    {
        List<BookServeModel>L=new ArrayList<BookServeModel>();
        try{
            String sql="select *from "+table+";";
            rs=DBState().executeQuery(sql);
            while(rs.next())
            {
                BookServeModel m=new BookServeModel();
                m.setId(rs.getString("ID"));
                m.setCallno(rs.getString("CallNo"));
                m.setTaken_date(rs.getString("Taken_Date"));
                m.setReturn_date(rs.getString("Return_Date"));
                m.setFine(rs.getString("Fine"));
                L.add(m);
                
            }
            CloseAll();
        }catch (Exception ex) {
            ex.printStackTrace();
        }
        return L;
    }
    
    
    public void CloseAll() throws SQLException
    {
        if(rs!=null)rs.close();
        if(st!=null)st.close();
        if(con!=null)con.close();
    }
}


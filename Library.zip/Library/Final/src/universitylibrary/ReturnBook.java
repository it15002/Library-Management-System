package universitylibrary;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class ReturnBook {
    private ResultSet rs=null;
    private Controller control=new Controller();
    ReturnBook()
    {
        init();
    }
    private void init()
    {
        JFrame frame=new JFrame();
        JLabel head;
        
        Font font;
        Container c;
        font=new Font("Arial",Font.BOLD,18);
        frame.setVisible(true);
        frame.setTitle("Library Management System");
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	c =frame.getContentPane();
	c.setLayout(null);
        c.setBackground(Color.ORANGE);
        frame.setBounds(0,0,1000,1000);
        
        head=new JLabel("Return Book");
        head.setBounds(100,10,200,30);
        head.setFont(font);
        
        c.add(head);
        
        JLabel lblid=new JLabel("Enter ID"),lblcall=new JLabel("Enter CallNo"),lbltakendate=new JLabel("Enter Date");
        JTextField txtid=new JTextField(),txtcall=new JTextField(),txttakendate=new JTextField();
        
        lblid.setBounds(10,100,150,30);
        lblid.setFont(font);
        txtid.setBounds(200,100,200,30);
        txtid.setFont(font);
        lblcall.setBounds(10,140,150,30);
        lblcall.setFont(font);
        txtcall.setBounds(200,140,200,30);
        txtcall.setFont(font);
        lbltakendate.setBounds(10,180,150,30);
        lbltakendate.setFont(font);
        txttakendate.setBounds(200,180,200,30);
        txttakendate.setFont(font);
        txttakendate.setToolTipText("Format: YY-MM-DD");
        JButton btntake=new JButton("Return"),btnback=new JButton("Back");
        btntake.setBounds(100,240,100,30);
        btntake.setFont(font);
        btnback.setBounds(100,280,100,30);
        btnback.setFont(font);
        
        c.add(lblid);c.add(txtid);c.add(lblcall);c.add(txtcall);
        c.add(lbltakendate);c.add(txttakendate);c.add(btntake);c.add(btnback);
        
        btntake.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                String x="";
                boolean check=false;
                int fine=0;
                String sql="select *from bookservice where ID='"+txtid.getText()+"';";
                try {
                    rs=control.DBState().executeQuery(sql);
                    while(rs.next())
                    {
                        x=rs.getString("Taken_date");
                    }
                    
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Something wrong");
                    ex.printStackTrace();
                }
                if(!x.equals(""))
                {
                    float dif=0.0f;
                    sql="SELECT julianday('"+txttakendate.getText()+"')- julianday('"+x+"') as Result;";
                    try {
                        rs=control.DBState().executeQuery(sql);
                        while(rs.next())dif=rs.getFloat("Result");
                        control.CloseAll();
                        //System.out.println(dif);
                    } catch (SQLException ex) {
                        Logger.getLogger(ReturnBook.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    
                    try {
                        fine=(int)dif;
                        String res="";
                        if(fine>7)
                        {
                            res=String.valueOf((fine-7)*2);
                            //res=String.valueOf(Math.abs(Integer.valueOf(dif)));
                        }
                        else res="";
                        //dif="";
                        
                        sql="update bookservice set Return_Date='"+txttakendate.getText()+"',Fine='"+dif+"',Taken_Date='"+x+"' where ID='"+txtid.getText()+"';";
                        control.DBState().executeUpdate(sql);
                        control.CloseAll();
                        check=true;
                        
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(null, "Something wrong");
                        ex.printStackTrace();
                    }
                    
                    sql="select *from books where CallNo='"+txtcall.getText()+"';";
                    String p="";
                    try {
                        rs=control.DBState().executeQuery(sql);
                        while(rs.next())p=rs.getString("Quantity");
                        control.CloseAll();
                        if(p.equals(""))p="0";
                        int book=Integer.valueOf(p);
                        book++;
                        p=String.valueOf(book);
                        
                    } catch (SQLException ex) {
                        Logger.getLogger(ReturnBook.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    try{
                        sql="update books set Quantity='"+p+"' where CallNo='"+txtcall.getText()+"';";
                        control.DBState().executeUpdate(sql);
                        control.CloseAll();
                    }catch (Exception ex) {
                        
                    }
                    if(check)JOptionPane.showMessageDialog(null,"Book successfully Returned");
                    else JOptionPane.showMessageDialog(null,"Something wrong.");
                }
                else JOptionPane.showMessageDialog(null,"May be it is your own book");
                
            }
        });
        
        btnback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
               StudentSection s=new StudentSection(); 
            }
        });
    }
    public static void main(String[] args) {
        ReturnBook ob=new ReturnBook();
        
    }
}

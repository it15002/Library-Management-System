package universitylibrary;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class StudentLog {
    private ResultSet rs=null;
    private Controller control=new Controller();
    StudentLog()
    {
        init();
    }
    private void init()
    {
        JFrame frame=new JFrame();
        JLabel lblname,lblpass,head;
        JTextField txtname;
        JPasswordField txtpass;
        JButton btnlogin,btnback;
        Font font;
        Container c;
        font=new Font("Arial",Font.BOLD,18);
        frame.setVisible(true);
        frame.setTitle("Library Management System");
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	c =frame.getContentPane();
	c.setLayout(null);
        c.setBackground(Color.ORANGE);
        frame.setBounds(0,0,1000,1000);
        
        head=new JLabel("Student Login Form");
        head.setBounds(100,10,200,30);
        head.setFont(font);
        
        lblname=new JLabel("Enter ID");
        lblname.setBounds(10,50,150,30);
        lblname.setFont(font);
        
        txtname=new JTextField();
        txtname.setBounds(160,50,150,30);
        txtname.setFont(font);
        
        lblpass=new JLabel("Enter Password");
        lblpass.setBounds(10,90,150,30);
        lblpass.setFont(font);
        
        txtpass=new JPasswordField();
        txtpass.setBounds(160,90,150,30);
        txtpass.setFont(font);
        
        btnlogin=new JButton("LogIn");
        btnlogin.setBounds(200,130,100,30);
        btnlogin.setFont(font);
        
        btnback=new JButton("Back");
        btnback.setBounds(30,130,100,30);
        btnback.setFont(font);
        
        c.add(head);
        c.add(lblname);
        c.add(txtname);
        c.add(lblpass);
        c.add(txtpass);
        c.add(btnback);
        c.add(btnlogin);
        
        btnback.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                frame.dispose();
                AdminLog log=new AdminLog();
            }
        });
        
        btnlogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                String username=txtname.getText();
                String password=txtpass.getText();
                String tab="student_form";
                String x="";
                String sql="select *from "+tab+" where ID='"+username+"' and Password='"+password+"';";
                try {
                    rs=control.DBState().executeQuery(sql);
                    while(rs.next())x=rs.getString("ID");
                    if(x.length()>0)
                    {
                        frame.dispose();
                        StudentSection ob=new StudentSection();
                    }
                    else JOptionPane.showMessageDialog(null,"Incorrect ID or Password.");
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Something wrong");
                    ex.printStackTrace();
                }
                
            }
        });
        
        
    }
    public static void main(String[] args) {
        StudentLog ob=new StudentLog();
    }
}
